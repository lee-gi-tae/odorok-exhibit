package com.odorok.OdorokApplication.infrastructures.service;

import static org.junit.jupiter.api.Assertions.*;

class DurunubiDataServiceImplTest {

}