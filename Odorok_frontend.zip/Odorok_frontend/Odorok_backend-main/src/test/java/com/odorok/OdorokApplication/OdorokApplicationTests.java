package com.odorok.OdorokApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdorokApplicationTests {

	@Test
	void contextLoads() {
	}

}
