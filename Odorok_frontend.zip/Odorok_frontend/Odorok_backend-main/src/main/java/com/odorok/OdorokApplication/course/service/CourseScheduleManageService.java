package com.odorok.OdorokApplication.course.service;

public interface CourseScheduleManageService {
}
