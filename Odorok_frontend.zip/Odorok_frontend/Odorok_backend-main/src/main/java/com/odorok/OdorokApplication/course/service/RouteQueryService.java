package com.odorok.OdorokApplication.course.service;

public interface RouteQueryService {
    String queryRouteNameByRouteIdx(String idx);
}
