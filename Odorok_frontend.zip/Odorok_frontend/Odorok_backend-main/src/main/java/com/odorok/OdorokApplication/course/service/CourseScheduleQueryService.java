package com.odorok.OdorokApplication.course.service;

import org.springframework.stereotype.Service;

public interface CourseScheduleQueryService {

}
