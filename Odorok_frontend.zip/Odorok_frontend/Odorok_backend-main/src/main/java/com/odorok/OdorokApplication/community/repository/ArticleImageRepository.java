package com.odorok.OdorokApplication.community.repository;

import com.odorok.OdorokApplication.draftDomain.ArticleImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArticleImageRepository extends JpaRepository<ArticleImage,Long> {
}
