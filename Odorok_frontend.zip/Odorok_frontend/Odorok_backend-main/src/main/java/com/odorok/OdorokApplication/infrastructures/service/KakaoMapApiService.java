//package com.odorok.OdorokApplication.infrastructures.service;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//public interface KakaoMapApiService {
//    public RegionInfo convertCoord2Region(Double latitude, Double longitude);
//
//    @Data
//    @AllArgsConstructor
//    @NoArgsConstructor
//    class RegionInfo {
//        String sido;
//        String sigungu;
//    }
//}
