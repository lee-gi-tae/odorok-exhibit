package com.odorok.OdorokApplication.region.dto.response.item;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class SidoSummary {
    private String name;
    private Integer sidoCode;
}
