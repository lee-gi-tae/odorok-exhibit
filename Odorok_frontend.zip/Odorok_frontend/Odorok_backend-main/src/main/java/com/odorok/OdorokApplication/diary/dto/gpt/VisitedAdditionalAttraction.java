package com.odorok.OdorokApplication.diary.dto.gpt;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class VisitedAdditionalAttraction {
    private String title;
    private String address;
    private String overview;
}
