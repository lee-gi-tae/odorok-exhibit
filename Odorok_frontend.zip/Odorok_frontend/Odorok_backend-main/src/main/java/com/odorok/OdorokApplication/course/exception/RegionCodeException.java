package com.odorok.OdorokApplication.course.exception;

public class RegionCodeException extends RuntimeException{
    public RegionCodeException(String msg){
        super(msg);
    }
}
