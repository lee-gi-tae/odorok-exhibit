<template>
  <div class="attractions-page">
    <!-- 뒤로가기 버튼 -->
    <div class="back-button" @click="$router.go(-1)">
      ← 뒤로가기
    </div>

    <!-- 코스 정보 -->
    <div class="course-info" v-if="course">
      <h1>{{ course.name }}</h1>
      <p class="course-summary">{{ course.summary }}</p>
    </div>

    <!-- 지도 영역 -->
    <div class="map-container">
      <KakaoMap 
        v-if="course && course.pathPoints && course.pathPoints.length > 0"
        :pathPoints="course.pathPoints"
        :courseId="course.id"
        :attractions="attractions"
      />
      <div v-else class="map-placeholder">
        <h3>지도 영역</h3>
        <p>코스 경로와 주변 명소가 마커로 표시됩니다</p>
      </div>
    </div>

    <!-- 주변 명소 섹션 -->
    <div class="attractions-section">
      <h2>주변 명소 (2km 이내)</h2>
      
      <!-- 로딩 상태 -->
      <div v-if="loading" class="loading">
        주변 명소를 찾는 중...
      </div>

      <!-- 에러 상태 -->
      <div v-else-if="error" class="error">
        {{ error }}
      </div>

      <!-- 명소 리스트 -->
      <div v-else-if="attractions.length > 0" class="attractions-grid">
        <div 
          v-for="attraction in attractions" 
          :key="attraction.attractionId"
          class="attraction-card"
          @click="showAttractionDetail(attraction)"
        >
          <div class="attraction-image">
            <img 
              :src="attraction.firstImage1 || '/placeholder-image.jpg'" 
              :alt="attraction.title"
              @error="handleImageError"
            />
          </div>
          <div class="attraction-info">
            <h3>{{ attraction.title }}</h3>
            <p class="address">{{ attraction.addr1 }}</p>
            <p class="tel" v-if="attraction.tel">📞 {{ attraction.tel }}</p>
            <div class="attraction-actions">
              <button 
                class="select-btn"
                @click.stop="toggleAttraction(attraction.attractionId)"
              >
                {{ selectedAttractions.includes(attraction.attractionId) ? '선택됨' : '선택' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- 명소가 없을 때 -->
      <div v-else class="no-attractions">
        주변 2km 이내에 명소가 없습니다.
      </div>
    </div>

    <!-- 여정 등록 버튼 -->
    <div class="journey-actions" v-if="selectedAttractions.length > 0">
      <button 
        class="create-journey-btn"
        @click="createJourney"
        :disabled="creatingJourney"
      >
        {{ creatingJourney ? '등록 중...' : `선택한 ${selectedAttractions.length}개 명소로 여정 등록` }}
      </button>
    </div>

    <!-- 명소 상세 정보 모달 -->
    <div v-if="selectedAttractionDetail" class="modal-overlay" @click="closeAttractionDetail">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h2>{{ selectedAttractionDetail.title }}</h2>
          <button class="close-btn" @click="closeAttractionDetail">×</button>
        </div>
        <div class="modal-body">
          <div class="attraction-detail-image">
            <img 
              :src="selectedAttractionDetail.firstImage1 || '/placeholder-image.jpg'" 
              :alt="selectedAttractionDetail.title"
            />
          </div>
          <div class="attraction-detail-info">
            <p><strong>주소:</strong> {{ selectedAttractionDetail.addr1 }}</p>
            <p v-if="selectedAttractionDetail.addr2"><strong>상세주소:</strong> {{ selectedAttractionDetail.addr2 }}</p>
            <p v-if="selectedAttractionDetail.tel"><strong>전화번호:</strong> {{ selectedAttractionDetail.tel }}</p>
            <p v-if="selectedAttractionDetail.homepage"><strong>홈페이지:</strong> <a :href="selectedAttractionDetail.homepage" target="_blank">{{ selectedAttractionDetail.homepage }}</a></p>
            <p v-if="selectedAttractionDetail.overview"><strong>설명:</strong> {{ selectedAttractionDetail.overview }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import KakaoMap from '../components/KakaoMap.vue'
import courses from '../data/courses.json'

const route = useRoute()
const courseId = parseInt(route.params.id)

// 코스 정보
const course = computed(() => {
  return courses.find(c => c.id === courseId)
})

// 상태 관리
const loading = ref(false)
const error = ref(null)
const attractions = ref([])
const selectedAttractions = ref([])
const creatingJourney = ref(false)
const selectedAttractionDetail = ref(null)

// 이미지 에러 처리
const handleImageError = (event) => {
  event.target.src = '/placeholder-image.jpg'
}

// 명소 선택/해제
const toggleAttraction = (attractionId) => {
  const index = selectedAttractions.value.indexOf(attractionId)
  if (index > -1) {
    selectedAttractions.value.splice(index, 1)
  } else {
    selectedAttractions.value.push(attractionId)
  }
}

// 명소 상세 정보 표시
const showAttractionDetail = (attraction) => {
  selectedAttractionDetail.value = attraction
}

// 명소 상세 정보 닫기
const closeAttractionDetail = () => {
  selectedAttractionDetail.value = null
}

// 주변 명소 조회 (코스 경로 기준 2km 이내)
const fetchNearbyAttractions = async () => {
  if (!course.value) return

  loading.value = true
  error.value = null

  try {
    // 코스의 모든 경로점을 기준으로 2km 이내 명소 조회
    const coursePath = course.value.pathPoints || []
    
    // 실제 API 호출 (현재는 더미 데이터 사용)
    // const response = await fetch(`/api/attractions/nearby?courseId=${courseId}`)
    // const data = await response.json()
    // attractions.value = data.items || []
    
    // 개발용 더미 데이터 (코스 경로 주변 2km 이내 명소들)
    attractions.value = [
      {
        attractionId: 1,
        title: '한강공원',
        firstImage1: 'https://via.placeholder.com/300x200',
        addr1: '서울시 강남구 한강대로',
        addr2: '한강공원 내',
        tel: '02-1234-5678',
        homepage: 'https://example.com',
        overview: '한강변의 아름다운 공원으로 산책과 휴식에 최적입니다.',
        latitude: 37.5665,
        longitude: 126.9780
      },
      {
        attractionId: 2,
        title: '코엑스몰',
        firstImage1: 'https://via.placeholder.com/300x200',
        addr1: '서울시 강남구 삼성로',
        addr2: '코엑스몰 1층',
        tel: '02-2345-6789',
        homepage: 'https://coexmall.com',
        overview: '대형 쇼핑몰로 다양한 쇼핑과 엔터테인먼트를 즐길 수 있습니다.',
        latitude: 37.5645,
        longitude: 126.9760
      },
      {
        attractionId: 3,
        title: '롯데월드타워',
        firstImage1: 'https://via.placeholder.com/300x200',
        addr1: '서울시 송파구 올림픽로',
        addr2: '롯데월드타워',
        tel: '02-3456-7890',
        homepage: 'https://lwt.co.kr',
        overview: '한국의 랜드마크로 서울의 아름다운 전경을 감상할 수 있습니다.',
        latitude: 37.5685,
        longitude: 126.9800
      }
    ]
  } catch (err) {
    console.error('주변 명소 조회 실패:', err)
    error.value = '주변 명소를 불러오는데 실패했습니다.'
  } finally {
    loading.value = false
  }
}

// 여정 등록
const createJourney = async () => {
  if (selectedAttractions.value.length === 0) return

  creatingJourney.value = true

  try {
    const journeyData = {
      userId: 1, // 임시 사용자 ID
      courseId: courseId,
      attractionIds: selectedAttractions.value
    }

    // 실제 API 호출 (현재는 더미 응답)
    // const response = await fetch('/api/journeys', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(journeyData)
    // })
    // const journeyId = await response.json()

    // 개발용 더미 응답
    const journeyId = Math.floor(Math.random() * 1000) + 1
    
    alert(`여정이 성공적으로 등록되었습니다! (여정 ID: ${journeyId})`)
    
    // 선택 초기화
    selectedAttractions.value = []
  } catch (err) {
    console.error('여정 등록 실패:', err)
    alert('여정 등록에 실패했습니다.')
  } finally {
    creatingJourney.value = false
  }
}

// 컴포넌트 마운트 시 주변 명소 조회
onMounted(() => {
  fetchNearbyAttractions()
})
</script>

<style scoped>
.attractions-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.back-button {
  cursor: pointer;
  color: #007bff;
  margin-bottom: 20px;
  font-weight: bold;
}

.course-info {
  margin-bottom: 30px;
}

.course-summary {
  line-height: 1.6;
  color: #333;
}

.map-container {
  margin-bottom: 30px;
}

.map-placeholder {
  background: #f8f9fa;
  border: 2px dashed #dee2e6;
  border-radius: 8px;
  padding: 40px;
  text-align: center;
  color: #6c757d;
}

.attractions-section h2 {
  margin-bottom: 20px;
  color: #333;
}

.loading, .error, .no-attractions {
  text-align: center;
  padding: 40px;
  color: #666;
}

.error {
  color: #dc3545;
}

.attractions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.attraction-card {
  border: 1px solid #dee2e6;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s ease;
}

.attraction-card:hover {
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.attraction-image img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.attraction-info {
  padding: 15px;
}

.attraction-info h3 {
  margin: 0 0 10px 0;
  color: #333;
}

.address {
  color: #666;
  margin: 5px 0;
  font-size: 14px;
}

.tel {
  color: #007bff;
  margin: 5px 0;
  font-size: 14px;
}

.attraction-actions {
  margin-top: 15px;
}

.select-btn {
  padding: 8px 16px;
  border: 1px solid #007bff;
  background: white;
  color: #007bff;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.select-btn:hover {
  background: #007bff;
  color: white;
}

.journey-actions {
  margin-top: 30px;
  text-align: center;
}

.create-journey-btn {
  padding: 15px 30px;
  background: #28a745;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.3s ease;
}

.create-journey-btn:hover:not(:disabled) {
  background: #218838;
}

.create-journey-btn:disabled {
  background: #6c757d;
  cursor: not-allowed;
}

/* 모달 스타일 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 8px;
  max-width: 600px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #dee2e6;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #666;
}

.modal-body {
  padding: 20px;
}

.attraction-detail-image img {
  width: 100%;
  height: 300px;
  object-fit: cover;
  border-radius: 8px;
  margin-bottom: 20px;
}

.attraction-detail-info p {
  margin: 10px 0;
  line-height: 1.6;
}

.attraction-detail-info a {
  color: #007bff;
  text-decoration: none;
}

.attraction-detail-info a:hover {
  text-decoration: underline;
}
</style> 