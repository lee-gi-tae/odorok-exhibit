<template>
  <div class="signup-view">
    <h2>회원가입 폼</h2>
    <router-link to="/signup/consent"><button>다음</button></router-link>
  </div>
</template>
<script setup>
</script>
<style scoped>
.signup-view { display: flex; flex-direction: column; align-items: center; margin-top: 100px; }
button { margin-top: 20px; }
</style> 