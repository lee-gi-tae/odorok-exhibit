<template>
  <div style="display: flex; gap: 32px; align-items: flex-start;">
    <div style="flex:1; min-width: 350px; max-width: 500px;">
      <KakaoMap
        :pathPoints="selectedCourse && courseDetail && courseDetail.coords ? courseDetail.coords : []"
        :courseId="selectedCourse ? selectedCourse.id : 'all'"
        :attractions="attractionsWithEndPoint"
      />
    </div>
    <!-- 리스트/상세 영역 -->
    <div style="flex:2; min-width: 350px;">
      <h1>코스검색</h1>
      <div style="margin-bottom: 16px;">
        <button @click="selected = 'main'">메인</button>
        <button @click="selected = 'custom'">맞춤</button>
        <button @click="selected = 'region'">지역</button>
        <button @click="selected = 'all'">전체</button>
      </div>
      <!-- 페이지네이션: 현재 페이지에 해당하는 코스만 전달 -->
      <CourseMainTab v-if="selected === 'main'" :courses-prop="pagedCourses" />
      <CourseCustomTab v-if="selected === 'custom'" :courses-prop="pagedCourses" />
      <CourseRegionTab v-if="selected === 'region'" :courses-prop="pagedCourses" />
      <CourseAllTab v-if="selected === 'all'" :courses-prop="pagedCourses" />
      <!-- 페이지네이션 UI -->
      <div style="margin-top: 20px;">
        <button @click="prevPage" :disabled="currentPage === 1">이전</button>
        <span style="margin: 0 10px;">{{ currentPage }} / {{ totalPages }}</span>
        <button @click="nextPage" :disabled="currentPage === totalPages">다음</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import axios from 'axios'
import KakaoMap from '../components/KakaoMap.vue'
import CourseMainTab from '../components/CourseMainTab.vue'
import CourseCustomTab from '../components/CourseCustomTab.vue'
import CourseRegionTab from '../components/CourseRegionTab.vue'
import CourseAllTab from '../components/CourseAllTab.vue'

const selected = ref('main')
const courses = ref([])
const currentPage = ref(1)
const pageSize = 10
const selectedCourse = ref(null)
const courseDetail = ref(null)
const attractions = ref([])

const totalPages = computed(() => Math.ceil(courses.value.length / pageSize))
const pagedCourses = computed(() => {
  const start = (currentPage.value - 1) * pageSize
  return courses.value.slice(start, start + pageSize)
})

function prevPage() {
  if (currentPage.value > 1) currentPage.value--
}
function nextPage() {
  if (currentPage.value < totalPages.value) currentPage.value++
}

onMounted(async () => {
  try {
    const response = await axios.get('https://e634-14-42-221-117.ngrok-free.app/api/courses?page=0&size=500', {
      headers: {
        'ngrok-skip-browser-warning': true
      }
    });
    courses.value = (response.data.data.items || []).map(item => ({
      id: item.courseId || item.courseIdx,
      name: item.courseName || item.gilName,
      summary: item.gilName || '',
      distance: item.distance,
      difficulty: item.level,
      reqTime: item.reqTime,
      rating: item.rating || 0,
      visited: item.visited,
      latitude: item.latitude,
      longitude: item.longitude,
      sidoCode: item.sidoCode,
      sigunguCode: item.sigunguCode,
      contentTypeId: item.contentTypeId
    }));
  } catch (error) {
    console.error('코스 데이터 불러오기 실패:', error.response || error.message);
  }
});

// attractionsWithEndPoint 계산 (도착점 추가)
const attractionsWithEndPoint = computed(() => {
  if (!courseDetail.value || !courseDetail.value.coords || courseDetail.value.coords.length === 0) return attractions.value;
  const endCoord = courseDetail.value.coords[courseDetail.value.coords.length - 1];
  return [
    ...attractions.value,
    {
      attractionId: 'END',
      title: '도착점',
      latitude: endCoord.latitude,
      longitude: endCoord.longitude,
      isEndPoint: true
    }
  ];
});
</script> 