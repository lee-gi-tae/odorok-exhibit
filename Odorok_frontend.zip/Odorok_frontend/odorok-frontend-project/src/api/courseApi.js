import axios from 'axios';

const API_BASE_URL = 'https://e634-14-42-221-117.ngrok-free.app/api';
const ngrokHeaders = { 'ngrok-skip-browser-warning': true };

const courseApi = {
  // 지역별 코스 검색
  searchByRegion: async (sidoCode, sigunguCode, email = null, page = 0, size = 10) => {
    try {
      const params = {
        sidoCode,
        sigunguCode,
        page,
        size
      };
      
      if (email) {
        params.email = email;
      }

      const response = await axios.get(`${API_BASE_URL}/courses/region`, { params, headers: ngrokHeaders });
      return response.data;
    } catch (error) {
      console.error('코스 검색 중 오류 발생:', error);
      throw error;
    }
  },

  // 코스 상세 정보 조회
  getCourseDetail: async (courseId) => {
    const response = await axios.get(`${API_BASE_URL}/courses/detail`, { params: { courseId }, headers: ngrokHeaders });
    return response.data;
  }
};

export default courseApi; 