// 백엔드 서버가 실행되지 않을 때 사용할 목 데이터

export const mockSidoList = [
  { code: 11, name: '서울특별시' },
  { code: 26, name: '부산광역시' },
  { code: 27, name: '대구광역시' },
  { code: 28, name: '인천광역시' },
  { code: 29, name: '광주광역시' },
  { code: 30, name: '대전광역시' },
  { code: 31, name: '울산광역시' },
  { code: 36, name: '세종특별자치시' },
  { code: 41, name: '경기도' },
  { code: 42, name: '강원도' },
  { code: 43, name: '충청북도' },
  { code: 44, name: '충청남도' },
  { code: 45, name: '전라북도' },
  { code: 46, name: '전라남도' },
  { code: 47, name: '경상북도' },
  { code: 48, name: '경상남도' },
  { code: 50, name: '제주특별자치도' }
];

export const mockSigunguList = {
  11: [ // 서울특별시
    { code: 110, name: '종로구' },
    { code: 140, name: '중구' },
    { code: 170, name: '용산구' },
    { code: 200, name: '성동구' },
    { code: 215, name: '광진구' },
    { code: 230, name: '동대문구' },
    { code: 260, name: '중랑구' },
    { code: 290, name: '성북구' },
    { code: 305, name: '강북구' },
    { code: 320, name: '도봉구' },
    { code: 350, name: '노원구' },
    { code: 380, name: '은평구' },
    { code: 410, name: '서대문구' },
    { code: 440, name: '마포구' },
    { code: 470, name: '양천구' },
    { code: 500, name: '강서구' },
    { code: 530, name: '구로구' },
    { code: 545, name: '금천구' },
    { code: 560, name: '영등포구' },
    { code: 590, name: '동작구' },
    { code: 620, name: '관악구' },
    { code: 650, name: '서초구' },
    { code: 680, name: '강남구' },
    { code: 710, name: '송파구' },
    { code: 740, name: '강동구' }
  ],
  41: [ // 경기도
    { code: 110, name: '수원시' },
    { code: 111, name: '수원시 장안구' },
    { code: 113, name: '수원시 권선구' },
    { code: 115, name: '수원시 팔달구' },
    { code: 117, name: '수원시 영통구' },
    { code: 130, name: '성남시' },
    { code: 131, name: '성남시 수정구' },
    { code: 133, name: '성남시 중원구' },
    { code: 135, name: '성남시 분당구' },
    { code: 150, name: '의정부시' },
    { code: 170, name: '안양시' },
    { code: 171, name: '안양시 만안구' },
    { code: 173, name: '안양시 동안구' },
    { code: 190, name: '부천시' },
    { code: 210, name: '광명시' },
    { code: 220, name: '평택시' },
    { code: 222, name: '동두천시' },
    { code: 224, name: '안산시' },
    { code: 225, name: '안산시 상록구' },
    { code: 227, name: '안산시 단원구' },
    { code: 250, name: '고양시' },
    { code: 251, name: '고양시 덕양구' },
    { code: 253, name: '고양시 일산동구' },
    { code: 255, name: '고양시 일산서구' },
    { code: 280, name: '과천시' },
    { code: 281, name: '구리시' },
    { code: 285, name: '남양주시' },
    { code: 287, name: '오산시' },
    { code: 290, name: '시흥시' },
    { code: 310, name: '군포시' },
    { code: 360, name: '의왕시' },
    { code: 370, name: '하남시' },
    { code: 390, name: '용인시' },
    { code: 391, name: '용인시 처인구' },
    { code: 393, name: '용인시 기흥구' },
    { code: 395, name: '용인시 수지구' },
    { code: 410, name: '파주시' },
    { code: 415, name: '이천시' },
    { code: 420, name: '안성시' },
    { code: 425, name: '김포시' },
    { code: 450, name: '화성시' },
    { code: 460, name: '광주시' },
    { code: 465, name: '여주시' },
    { code: 480, name: '양평군' },
    { code: 500, name: '고양군' },
    { code: 520, name: '연천군' },
    { code: 550, name: '가평군' },
    { code: 570, name: '포천군' }
  ]
};

export const mockCourses = [
  {
    id: 1,
    name: '한강공원 걷기 코스',
    description: '한강변을 따라 걷는 아름다운 코스',
    distance: 5.2,
    duration: 120,
    difficulty: '쉬움',
    region: '서울특별시',
    imageUrl: '/images/course1.jpg'
  },
  {
    id: 2,
    name: '북한산 둘레길',
    description: '북한산을 한 바퀴 도는 둘레길',
    distance: 8.5,
    duration: 180,
    difficulty: '보통',
    region: '서울특별시',
    imageUrl: '/images/course2.jpg'
  },
  {
    id: 3,
    name: '남산타워 산책로',
    description: '남산타워까지 올라가는 산책로',
    distance: 3.8,
    duration: 90,
    difficulty: '쉬움',
    region: '서울특별시',
    imageUrl: '/images/course3.jpg'
  }
];

// 목 API 클라이언트
export const mockApi = {
  getSidoList: () => Promise.resolve({ status: 'success', data: mockSidoList }),
  getSigunguList: (sidoCode) => Promise.resolve({ 
    status: 'success', 
    data: mockSigunguList[sidoCode] || [] 
  }),
  searchCourses: (sidoCode, sigunguCode) => Promise.resolve({ 
    status: 'success', 
    data: { items: mockCourses } 
  })
}; 