<template>
  <div v-if="pathPoints && pathPoints.length > 0" :id="mapId" style="width: 100%; height: 400px;"></div>
  <div v-else style="color:#888; margin-top:16px;">경로 정보가 없습니다.</div>
</template>

<script>
const KAKAO_MAP_KEY = '0b27ae4cd1f6d5855f45311d8cecb15f'; // 여기에 본인 앱키 입력

let kakaoMapScriptLoading = false;
let kakaoMapScriptLoaded = false;
let kakaoMapScriptPromise = null;

export default {
  name: 'KakaoMap',
  props: {
    pathPoints: {
      type: Array,
      required: true
    },
    courseId: {
      type: [String, Number],
      required: true
    },
    attractions: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    mapId() {
      return 'map-' + this.courseId;
    }
  },
  mounted() {
    this.loadKakaoMapScript().then(() => {
      this.initMap();
    }).catch((e) => {
      alert('카카오맵 스크립트 로드 실패: ' + e);
    });
  },
  methods: {
    loadKakaoMapScript() {
      if (kakaoMapScriptLoaded) return Promise.resolve();
      if (kakaoMapScriptLoading) return kakaoMapScriptPromise;
      kakaoMapScriptLoading = true;
      kakaoMapScriptPromise = new Promise((resolve, reject) => {
        if (window.kakao && window.kakao.maps) {
          kakaoMapScriptLoaded = true;
          resolve();
          return;
        }
        const script = document.createElement('script');
        script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${KAKAO_MAP_KEY}&autoload=false`;
        script.onload = () => {
          window.kakao.maps.load(() => {
            kakaoMapScriptLoaded = true;
            resolve();
          });
        };
        script.onerror = reject;
        document.head.appendChild(script);
      });
      return kakaoMapScriptPromise;
    },
    initMap() {
      if (!this.pathPoints || this.pathPoints.length === 0) return;
      const mapContainer = document.getElementById(this.mapId);
      if (!mapContainer) {
        alert('지도 div를 찾을 수 없습니다: ' + this.mapId);
        return;
      }
      const mapOption = {
        center: new window.kakao.maps.LatLng(this.pathPoints[0].latitude, this.pathPoints[0].longitude),
        level: 5,
      };
      const map = new window.kakao.maps.Map(mapContainer, mapOption);
      const linePath = this.pathPoints.map(p => new window.kakao.maps.LatLng(p.latitude, p.longitude));
      new window.kakao.maps.Polyline({
        path: linePath,
        strokeWeight: 5,
        strokeColor: '#FF0000',
        strokeOpacity: 0.8,
        strokeStyle: 'solid',
        map: map,
      });
      // 시작점 마커
      new window.kakao.maps.Marker({
        position: linePath[0],
        map: map,
      });
      
      // 명소 마커들 추가
      this.attractions.forEach(attraction => {
        if (attraction.latitude && attraction.longitude) {
          const marker = new window.kakao.maps.Marker({
            position: new window.kakao.maps.LatLng(attraction.latitude, attraction.longitude),
            map: map,
          });
          
          // 명소 정보창
          const infowindow = new window.kakao.maps.InfoWindow({
            content: `
              <div style="padding:10px; min-width:200px;">
                <h4 style="margin:0 0 5px 0;">${attraction.title}</h4>
                <p style="margin:0; font-size:12px; color:#666;">${attraction.addr1}</p>
                ${attraction.tel ? `<p style="margin:5px 0 0 0; font-size:12px; color:#007bff;">📞 ${attraction.tel}</p>` : ''}
              </div>
            `
          });
          
          // 마커 클릭 시 정보창 표시
          window.kakao.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map, marker);
          });
        }
      });
      
      map.setCenter(linePath[0]);
    }
  },
  watch: {
    pathPoints(newVal) {
      if (newVal && newVal.length > 0 && kakaoMapScriptLoaded) {
        this.initMap();
      }
    },
    attractions(newVal) {
      if (newVal && newVal.length > 0 && kakaoMapScriptLoaded) {
        this.initMap();
      }
    }
  }
};
</script> 