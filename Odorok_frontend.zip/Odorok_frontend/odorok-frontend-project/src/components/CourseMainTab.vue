<template>
  <div>
    <h2>추천코스 리스트</h2>
    <ul v-if="pagedCourses.length > 0">
      <li v-for="course in pagedCourses" :key="course.id" @click="selectCourse(course)" style="cursor:pointer;">
        <strong>{{ course.name }}</strong> ({{ course.distance }}km)
        <span style="margin-left:8px; color:#888; font-size:13px;">난이도: {{ course.difficulty }}, 별점: {{ course.rating }}</span>
      </li>
    </ul>
    <div v-else>코스 데이터가 없습니다.</div>
    <div style="margin-top: 20px;">
        <button @click="prevPage" :disabled="currentPage === 1">이전</button>
        <span style="margin: 0 10px;">{{ currentPage }} / {{ totalPages }}</span>
        <button @click="nextPage" :disabled="currentPage === totalPages">다음</button>
    </div>
    <!-- 상세 정보 영역 -->
    <div v-if="selectedCourse" style="margin-top:32px; display: flex; flex-direction: column; gap: 24px; align-items: flex-start; border-top: 2px solid #bbb; padding-top: 24px; max-width: 500px;">
      <div style="font-size: 2rem; font-weight: bold; margin-bottom: 18px;">코스 상세 정보</div>
      <div style="font-size: 1.2rem; margin-bottom: 10px;"><strong>코스명:</strong> {{ selectedCourse.name }}</div>
      <div style="font-size: 1.2rem; margin-bottom: 10px;"><strong>코스거리:</strong> {{ selectedCourse.distance }}km</div>
      <div style="font-size: 1.2rem; margin-bottom: 10px;"><strong>난이도:</strong> {{ selectedCourse.difficulty }}</div>
      <div style="font-size: 1.2rem; margin-bottom: 10px;"><strong>예상소요시간:</strong> {{ selectedCourse.reqTime }}</div>
      <div style="font-size: 1.2rem; margin-bottom: 10px;"><strong>별점:</strong> {{ selectedCourse.rating }} / 5.0</div>
      <div v-if="courseDetail" style="font-size: 1.2rem; margin-bottom: 10px;"><strong>코스 설명:</strong> {{ courseDetail.contents }}</div>
      <div v-if="$parent.selected === 'all'" style="display: flex; gap: 16px; margin: 24px 0 0 0; width: 100%; justify-content: flex-start;">
        <button @click="fetchAttractions" style="padding:8px 18px; background:#447cff; color:white; border:none; border-radius:6px; cursor:pointer; font-weight:bold; font-size:1.1rem;">주변 명소 보기 (2km 이내)</button>
      </div>
      <div v-if="courseDetail && courseDetail.coords && courseDetail.coords.length > 0" style="margin-top: 24px; width: 100%;">
        <KakaoMap :pathPoints="courseDetail.coords" :courseId="selectedCourse.id" :attractions="attractionsWithEndPoint" />
      </div>
    </div>
  </div>
</template>

<script>
import KakaoMap from './KakaoMap.vue'
import courseApi from '../api/courseApi.js'
import axios from 'axios'
const NGROK_HEADERS = { 'ngrok-skip-browser-warning': true };
export default {
  name: 'CourseMainTab',
  components: { KakaoMap },
  props: {
    coursesProp: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      selectedCourse: null,
      courseDetail: null,
      attractions: [],
      currentPage: 1,
      pageSize: 5
    }
  },
  computed: {
    sortedByDistance() {
      let sorted = [...this.coursesProp];
      return sorted.sort((a, b) => (a.distance || 0) - (b.distance || 0));
    },
    pagedCourses() {
      const start = (this.currentPage - 1) * this.pageSize;
      return this.sortedByDistance.slice(start, start + this.pageSize);
    },
    totalPages() {
      return Math.ceil(this.sortedByDistance.length / this.pageSize);
    },
    attractionsWithEndPoint() {
      if (!this.courseDetail || !this.courseDetail.coords || this.courseDetail.coords.length === 0) return this.attractions;
      const endCoord = this.courseDetail.coords[this.courseDetail.coords.length - 1];
      return [
        ...this.attractions,
        {
          attractionId: 'END',
          title: '도착점',
          latitude: endCoord.latitude,
          longitude: endCoord.longitude,
          isEndPoint: true
        }
      ];
    }
  },
  watch: {
    selectedCourse(newCourse) {
      if (newCourse && newCourse.id) {
        this.fetchCourseDetail(newCourse.id);
      } else {
        this.courseDetail = null;
        this.attractions = [];
      }
    }
  },
  methods: {
    selectCourse(course) {
      this.selectedCourse = course;
    },
    prevPage() {
      if (this.currentPage > 1) this.currentPage--;
    },
    nextPage() {
      if (this.currentPage < this.totalPages) this.currentPage++;
    },
    async fetchCourseDetail(courseId) {
      try {
        const response = await courseApi.getCourseDetail(courseId);
        if (response && response.status === 'success') {
          this.courseDetail = response.data;
        } else {
          this.courseDetail = null;
        }
      } catch (e) {
        this.courseDetail = null;
      }
    },
    async fetchAttractions() {
      if (!this.selectedCourse) return;
      // 실제로는 selectedCourse에 sidoCode, sigunguCode, contentTypeId가 있어야 함
      const params = {
        sidoCode: this.selectedCourse.sidoCode || 1,
        sigunguCode: this.selectedCourse.sigunguCode || 1,
        contentTypeId: this.selectedCourse.contentTypeId || 21
      };
      try {
        const response = await axios.get('https://e634-14-42-221-117.ngrok-free.app/api/attractions/region', { params, headers: NGROK_HEADERS });
        if (response.data && response.data.status === 'success') {
          this.attractions = response.data.data.items;
        } else {
          this.attractions = [];
        }
      } catch (e) {
        this.attractions = [];
      }
    }
  }
}
</script> 