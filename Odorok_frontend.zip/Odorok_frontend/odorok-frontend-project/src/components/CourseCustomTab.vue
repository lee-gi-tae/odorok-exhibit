<template>
  <div>
    <h2>맞춤 추천코스 리스트</h2>
    <!-- 소팅 드롭다운 -->
    <div style="margin-bottom: 16px;">
      <label for="sortSelect">정렬 기준: </label>
      <select id="sortSelect" v-model="sortType">
        <option value="distance">거리순</option>
        <option value="difficulty">난이도순</option>
        <option value="rating">별점순</option>
      </select>
    </div>
    <div v-if="sortedCourses.length > 0">
      <ul>
        <li v-for="course in sortedCourses" :key="course.id" @click="selectCourse(course)" style="cursor:pointer;">
          <strong>{{ course.name }}</strong> ({{ course.distance }}km)
        </li>
      </ul>
    </div>
    <div v-else>추천 코스 데이터가 없습니다.</div>

    <div v-if="selectedCourse" style="margin-top:32px; border-top:1px solid #ccc; padding-top:16px; position:relative;">
      <div v-if="selectedCourse.visited" style="position:absolute; top:0; right:0; background:#4caf50; color:white; padding:4px 12px; border-radius:0 0 0 8px; font-size:14px;">방문한 코스입니다</div>
      <h3>코스 상세 정보</h3>
      <div><strong>코스명:</strong> {{ selectedCourse.name }}</div>
      <div><strong>코스거리:</strong> {{ selectedCourse.distance }}km</div>
      <div><strong>난이도:</strong> {{ selectedCourse.difficulty }}</div>
      <div><strong>예상소요시간:</strong> {{ selectedCourse.reqTime }}분</div>
      <div><strong>코스 설명:</strong> {{ selectedCourse.summary }}</div>
      <div><strong>별점:</strong> {{ selectedCourse.rating }} / 5.0</div>
      
      <!-- 명소보기 버튼 -->
      <div style="margin-top:20px;">
        <button 
          @click="goToAttractions"
          style="padding:10px 20px; background:#007bff; color:white; border:none; border-radius:6px; cursor:pointer; font-weight:bold;"
        >
          주변 명소 보기 (2km 이내)
        </button>
      </div>
      
      <div style="margin-top:16px; width:300px; height:200px; background:#e0e0e0; display:flex; align-items:center; justify-content:center; flex-direction:column;">
        <div>지도 영역(임시)</div>
        <div style="font-size:12px; color:#555; margin-top:8px;">
          위도: {{ selectedCourse.latitude }} / 경도: {{ selectedCourse.longitude }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CourseCustomTab',
  props: {
    coursesProp: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      sortType: 'distance',
      selectedCourse: null
    }
  },
  computed: {
    sortedCourses() {
      let sorted = [...this.coursesProp];
      if (this.sortType === 'distance') {
        sorted.sort((a, b) => (a.distance || 0) - (b.distance || 0));
      } else if (this.sortType === 'difficulty') {
        sorted.sort((a, b) => (a.difficulty || '').localeCompare(b.difficulty || ''));
      } else if (this.sortType === 'rating') {
        sorted.sort((a, b) => (b.rating || 0) - (a.rating || 0));
      }
      return sorted;
    }
  },
  methods: {
    selectCourse(course) {
      this.selectedCourse = course;
    },
    goToAttractions() {
      // 명소 페이지로 이동 (코스 ID와 함께)
      this.$router.push(`/attractions/${this.selectedCourse.id}`);
    },
    levelText(level) {
      if (level === 1) return '하'
      if (level === 2) return '중'
      if (level === 3) return '상'
      return '-'
    }
  }
}
</script> 