import { createRouter, createWebHistory } from 'vue-router'
import CourseSearchView from '../views/CourseSearchView.vue'
import AttractionsView from '../views/AttractionsView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/course-search',
      name: 'CourseSearch',
      component: CourseSearchView,
    },
    {
      path: '/attractions/:id',
      name: 'Attractions',
      component: AttractionsView,
    },
    {
      path: '/login',
      name: 'Login',
      component: () => import('../views/LoginView.vue')
    },
    {
      path: '/signup',
      name: 'Signup',
      component: () => import('../views/SignupView.vue')
    },
    {
      path: '/signup/consent',
      name: 'SignupConsent',
      component: () => import('../views/SignupConsentView.vue')
    },
    {
      path: '/signup/health',
      name: 'SignupHealth',
      component: () => import('../views/SignupHealthView.vue')
    },
    {
      path: '/signup/complete',
      name: 'SignupComplete',
      component: () => import('../views/SignupCompleteView.vue')
    },
  ],
})

export default router
